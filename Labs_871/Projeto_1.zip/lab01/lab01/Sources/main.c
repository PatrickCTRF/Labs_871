// Experi�ncia 1 - EA871-2S2016 - Pisca LEDs do RGB placa Freedom




// LEDs com catodo ligado em PTB18




#define SIM_SCGC5   (*(unsigned int volatile *) 0x40048038) // Habilita as Portas do GPIO (Reg. SIM_SCGC5)

#define PORTB_PCR18 (*(unsigned int volatile *) 0x4004A048) // MUX de PTB18 (Reg. PORTB_PCR18)

#define GPIOB_PDDR  (*(unsigned int volatile *) 0x400FF054) // Data direction do PORTB (Reg. GPIOB_PDDR)

#define GPIOB_PSOR  (*(unsigned int volatile *) 0x400FF044) // Set bit register do PORTB (Reg. GPIOB_PSOR)

#define GPIOB_PCOR  (*(unsigned int volatile *) 0x400FF048) // Clear bit register do PORTB (Reg. GPIOB_PCOR)

#define PORTB_PCR19 (*(unsigned int volatile *) 0x4004A04C) // MUX de PTB18 (Reg. PORTB_PCR18)

#define PORTD_PCR1 (*(unsigned int volatile *) 0x4004C004) // MUX de PTB18 (Reg. PORTB_PCR18)

#define GPIOD_PDDR  (*(unsigned int volatile *) 0x400FF0D4) // Data direction do PORTB (Reg. GPIOB_PDDR)

#define GPIOD_PSOR  (*(unsigned int volatile *) 0x400FF0C4) // Set bit register do PORTB (Reg. GPIOB_PSOR)

#define GPIOD_PCOR  (*(unsigned int volatile *) 0x400FF0C8) // Clear bit register do PORTB (Reg. GPIOB_PCOR)




void delay( unsigned int i) {

    while (i)

        i--;

}




int main( void){
	
	int red[] = 	{1,0,0,0,0,0,1,0,1,0,0,0},//Interpretando estes arrays como uma matriz, cada coluna representa uma combina��o dos tr�s LEDs.
		green[] = 	{0,0,1,0,0,0,1,0,0,0,1,0},
		blue[] = 	{0,0,0,0,1,0,0,0,1,0,1,0},
		i=0;

	SIM_SCGC5   = SIM_SCGC5   | (1<<10) | (1<<12);    // Habilita clock GPIO do PORTB
	PORTB_PCR18 = PORTB_PCR18 & 0xFFFFF8FF; // Zera bits 10, 9 e 8 (MUX) de PTB18
	PORTB_PCR18 = PORTB_PCR18 | 0x00000100; // Seta bit 8 do MUX de PTB18, assim os 3 bits de MUX ser�o 001
	PORTB_PCR19 = PORTB_PCR19 | 0x00000100; // Seta bit 8 do MUX de PTB18, assim os 3 bits de MUX ser�o 001
	GPIOB_PDDR  = GPIOB_PDDR  | (1<<18);    // Seta pino 18 do PORTB como sa�da
	GPIOB_PDDR  = GPIOB_PDDR  | (1<<19);    // Seta pino 19 do PORTB como sa�da
	GPIOD_PDDR  = GPIOD_PDDR  | (1<<1);    // Seta pino 1 do PORTB como sa�da
	PORTD_PCR1 = PORTD_PCR1 & 0xFFFFF8FF; // Zera bits 10, 9 e 8 (MUX) de PTD18
	PORTD_PCR1 = PORTD_PCR1 | 0x00000100; // Seta bit 8 do MUX de PTB18, assim os 3 bits de MUX ser�o 001

	for(i=0;i<=12;i++) {
		
		if(i>=12) i=0;
		
		if(!red[i]) GPIOB_PSOR = (1<<18);// Set bit 18, LED vermelho em PTB18 (apaga)
		else GPIOB_PCOR = (1<<18);// Clear bit 18, LED vermelho em PTB18 (acende)
	
		if(!green[i]) GPIOB_PSOR = (1<<19);// Set bit 19, LED vermelho em PTB19 (apaga)
		else GPIOB_PCOR = (1<<19);// Clear bit 19, LED vermelho em PTB19 (acende)
	
		if(!blue[i]) GPIOD_PSOR = (1<<1);// Set bit 18, LED vermelho em PTB18 (apaga)
		else GPIOD_PCOR = (1<<1);// Clear bit 18, LED vermelho em PTB18 (acende)
	
		delay(500000);
	
	}

}
