//175480_12





/*
 * Este programa faz a modula��o por largura de pulso no pino PTB0.
 * 
 * Para aumentar a velocidade do cooler, o usu�rio pode pressionar a tecla
 * "+" do teclado no terminal ou pressionar o bot�o S1 (nmi) na placa.
 * Para diminuir a velocidade do cooler, o usu�rio pode pressionar a tecla
 * "-" do teclado no terminal ou pressionar o bot�o S2 (IRQ5) na placa.
 */

#include "UART.h"
#include "LCD.h"
#include"derivative.h"

#define NMAX 1024

#define HR (n[n[0]]/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MIN ((n[n[0]]%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEG (((n[n[0]]%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENT (((n[n[0]]%360000)%6000)%100) //Cent�simos.

#define HRlap (n[i]/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MINlap ((n[i]%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEGlap (((n[i]%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENTlap (((n[i]%360000)%6000)%100) //Cent�simos.

volatile int cent_global = 0, toggle1 = 0, toggle2 = 0, toggle3 = 0, comando = 0, flag4 = 0, flag5 = 0, flag6 = 0, buffer[NMAX] = {0}, n_buffer = 0, pi = 0, po = 0;
volatile char c=0, aux = 'P';

void getCommand(void);

void SysTick_Handler(){
	cent_global++;
}

void putchar(char c){
	UART0_C2 = 0x8C;//Habilita interrup��o de TRANSMISS�O de caracteres na UART0.
	
	while(!(n_buffer < NMAX));//Enquanto o buffer n�o possuir espa�os livres, aguarde.
	
	UART0_C2 = 0x2C;//Habilita interrup��o somente de RECEP��O de caracteres na UART0, pois agora n�o precisamos mais transmitir.
	
	buffer[pi++] = c;//Acrescenta o elemento no buffer e adianta o apontador em seguida.
	++n_buffer;//Acrescenta 1 ao contador de bytes no buffer, indicando que a a��o foi realizada.
	pi %= NMAX;//Verifica se o apontador pi atingiu o limite do buffer e, caso positivo, retorna-o ao in�cio do buffer, j� que � um buffer circular.
	
	UART0_C2 = 0x2C;//Habilita interrup��o de TRANSMISS�O de caracteres na UART0.
}

void puts_buffer(char *c){//fun��o que envia uma cadeia de caracteres (string) pela UART0 atrav�s do buffer.
	
	int i=0;
	
	for(i=0; c[i] != '\0'; i++)putchar(c[i]);//Envia, caracter por caracter, a frase para o buffer da UART.
	
}

void UART0_IRQHandler(){
	
	
	
	if(UART0_S1 & UART0_S1_RDRF_MASK){
		c = getchar_UART0();
		getCommand();
		c = 0;
	}
	
	if((UART0_S1 & UART0_S1_TDRE_MASK)&&n_buffer>0){//S� executa esta parte se houve uma interrup��o de Transmiss�o e o buffer possui algo a se transmitir.
		aux = buffer[po++];//Obt�m o elemento do buffer e adianta o apontador em seguida.
		--n_buffer;//Subtrai 1 do contador de bytes no buffer, indicando que a a��o foi realizada.
		po %= NMAX;//Verifica se o apontador po atingiu o limite do buffer e, caso positivo, retorna-o ao in�cio do buffer, j� que � um buffer circular.
		putchar_UART0(aux);
	}
	
	UART0_D = '\0';//Esta linha se faz necess�ria por algum motivo n�o evidente. Creio que seja por zerar a flag TDRE e cancelar a prox�ma chamada de TDRE.
}

void getCommand(void){
	

	comando = 0;//Caso nenhum dos if seja contemplado.									

	if(c == '+' || (PORTA_ISFR == 0 && toggle1 == 1)){	
		comando = 1;
	}
	if(c == '-' || (PORTA_ISFR == 32 && toggle1 == 0)){
		comando = 2;
	}
	
}



void NMI_Handler(){
	toggle1 = 1;
	getCommand();
	toggle1 = 0;
	return;
}

void PORTA_IRQHandler(){
	
	getCommand();
	
	PORTA_ISFR = (1<<5);
	PORTA_ISFR = (1<<12);
	
}


int main(void){
	
	
//======TODA A PARTE DE INICIALIZA��O=====================================================================================================================
	
	inicGPIO();//Fazendo toda a inicializa��o de software necess�ria.
	inicLCD(2);
	init_UART0();
	
	PORTA_PCR4 = 0x100;
	PORTA_PCR5 = 0x100;
	PORTA_PCR12 = 0x100;
	
	GPIOA_PDDR &= 0xFFFFEFCF;//Zera os bits 12, 5 e 4, configurando-os como input.
		
	
	PORTA_PCR5 = (0x100);
	PORTA_PCR5 |= (1<<19);
	PORTA_PCR5 |= (1<<16);
	PORTA_PCR12 = (0x100);
	PORTA_PCR12 |= (1<<19);
	PORTA_PCR12 |= (1<<16);
	PORTA_PCR4 = 0x0700;
	NVIC_ISER = (1<<30); //Habilita interrup��o na Porta A e na UART0.
	NVIC_ISER |= (1<<12);
	UART0_C2 = 0x2C;//Habilita interrup��o de RECEP��O de caracteres na UART0.
	
	SYST_RVR=210429;//Quantidade adequada para a interrup��o ocorrer a cada 10ms (verificado no oscilosc�pio).
	SYST_CVR=0;//Passa qualquer valor para CVR, o que faz isso voltar a zero e recarregar o valor a partir de RVR.
	SYST_CSR= 0b110;//Seta o registrador de controle para receber clock da CPU, lan�ar a exce��o do systic e n�o come�ar a contagem (respectivamente aos bits desta palavra).
	
	SIM_SOPT2 |= (1<<24);
	SIM_SCGC5 |= (1<<10);//Ativando clock da PORTB.
	SIM_SCGC6 = (1<<25);//Ativa o clock de TPM1.
	TPM1_SC = 0b100110;//Prescale em 64, LPTPM clock DISABLED (pois o center aligned s� se altera com contador desativado, � um pino protegido contra escrita em momento indevido), Center-aligned PWM em 1.
	TPM1_SC |= 0b001000;//Depois de configurar os pinos necess�rios, podemos ativar o contador (LPTPM counter).LPTPM clock ativado.
	TPM1_MOD = 1600;//Representa at� quanto o contador vai contar subindo e depois contar at� zero novamente. Logo, este valor representa metade do per�odop do pulso de chaveamento do PWM.
	//Como o clock da CPU � de 20,48MHz, dividimos ele no prescale por 64 e agora dividimos ele por 3200 (2*1600), resultando numa frequencia de chaveamento de 100Hz.
	TPM1_C0SC = 0;//O manual indica que este canal deve estar desativado para ser configurado, ent�o vou zer�-lo antes de come�ar qualquer configura��o.
	TPM1_C0SC = 0b101000;//Canal configurado para estar em alto antes de atingir o valor desejado e em baixo quando acima do valor desejado.
	PORTB_PCR0 = (0b11<<8);//Seta o MUX para transmitir neste pino a alternative 3 (ALT3), que envia o TPM1_CH0 para c�.
	TPM1_C0V = 0;//O valor que, quando counter atingir, far� alternar entre n�vel alto e baixo na sa�da
	TPM1_CNT = 0;
	
	
	puts_buffer("\r\n");// Ajusta o terminal para uma linha limpa.
		
	clear();//Limpa o lcd.
	
	
//======FIM DA PARTE DE INICIALIZA��O=====================================================================================================================
	
	
	

	
	puts_buffer("O percentual de velocidade �: 0%\r\n");//Imprime o que falta na frase e j� pula a linha.
	setString("Velocidade:  0%",0 ,0);//Imprime o que falta na frase e j� pula a linha.
	
	while(1){ //Daqui para frente o c�digo se repete at� o desligamento da placa.
	
		
		while(n_buffer >0)UART0_C2 = 0x8C;//Habilita interrup��o de TRANSMISS�O de caracteres na UART0.	
		UART0_C2 = 0x2C;//Desabilita interrup��o de TRANSMISS�O de caracteres na UART0.	
		//Isto serve apenas para ir esvaziando o buffer na UART0.
		
		
		
		if(comando==1){
			comando = 0;
			
			if(TPM1_C0V < 1440){
				
				TPM1_CNT = 0;
				TPM1_C0V += 160;//O valor que, quando counter atingir, far� alternar entre n�vel alto e baixo na sa�da.
				puts_buffer("O percentual de velocidade �: ");
				putchar(TPM1_C0V/160 + '0');//Obt�m o primeiro d�gito do percentual de velocidade e o converte em char. 
				puts_buffer("0%\r\n");//Imprime o que falta na frase e j� pula a linha.
				
				setString("Velocidade: ", 0, 0);
				setChar(TPM1_C0V/160 + '0');//Obt�m o primeiro d�gito do percentual de velocidade e o converte em char. 
				setChar('0');//Imprime o que falta na frase e j� pula a linha.
				setChar('%');
				
			} else if(TPM1_C0V == 1440){
				
				TPM1_CNT = 0;
				TPM1_C0V += 160;//O valor que, quando counter atingir, far� alternar entre n�vel alto e baixo na sa�da.
				puts_buffer("O percentual de velocidade �: 100%\r\n");//Imprime o que falta na frase e j� pula a linha.
				
				setString("Velocidade:100%", 0, 0);//Imprime o que falta na frase e j� pula a linha.
				
			} else{//Se nao atender nenhuma das condi��es anteriores, significa que j� estamos no valor m�ximo.
				
				puts_buffer("O percentual de velocidade �: 100%\r\n");//Imprime o que falta na frase e j� pula a linha.
				
				setString("Velocidade:100%", 0, 0);//Imprime o que falta na frase e j� pula a linha.
				
			}
		}//Se pressionar o bot�o +, aumente a velocidade do cooler.
		
		
		if(comando==2){
			comando = 0;
			
			if(TPM1_C0V > 160){//Se estivermos at� o pen�ltimo valor mais baixo...
				
				TPM1_CNT = 0;
				TPM1_C0V -= 160;//O valor que, quando counter atingir, far� alternar entre n�vel alto e baixo na sa�da.
				puts_buffer("O percentual de velocidade �: ");
				putchar(TPM1_C0V/160 + '0');//Obt�m o primeiro d�gito do percentual de velocidade e o converte em char. 
				puts_buffer("0%\r\n");//Imprime o que falta na frase e j� pula a linha.
				
				setString("Velocidade: ", 0, 0);
				setChar(TPM1_C0V/160 + '0');//Obt�m o primeiro d�gito do percentual de velocidade e o converte em char. 
				setChar('0');//Imprime o que falta na frase e j� pula a linha.
				setChar('%');
				
			} else if(TPM1_C0V == 160){
				
				TPM1_CNT = 0;
				TPM1_C0V -= 160;//O valor que, quando counter atingir, far� alternar entre n�vel alto e baixo na sa�da.
				puts_buffer("O percentual de velocidade �: 0%\r\n");//Imprime o que falta na frase e j� pula a linha.
				
				setString("Velocidade:  0%", 0, 0);//Imprime o que falta na frase e j� pula a linha.
				
			} else{//Se nao atender nenhuma das condi��es anteriores, significa que j� estamos no valor m�nimo.
				
				puts_buffer("O percentual de velocidade �: 0%\r\n");//Imprime o que falta na frase e j� pula a linha.
				
				setString("Velocidade:  0%", 0, 0);//Imprime o que falta na frase e j� pula a linha.
				
			}
					
		}//Se pressionar o bot�o 2, diminua a velocidade do cooler.
	}
	
	return 0;
}
