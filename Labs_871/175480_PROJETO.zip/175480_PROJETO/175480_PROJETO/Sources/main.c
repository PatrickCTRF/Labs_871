#include "derivative.h"
#include "i2c.h"
#include "MMA8451.h"
#include "LCD.h"
#include "UART.h"


int cent_global = 0, toggle1 = 0, comando = 0, flag4 = 0, flag5 = 0, flag6 = 0;
int linha_atual = 0, hora_da_ultima_atualizacao=0, pontuacao = 0, j = 0, boca = 0, dificuldade = 1 ;//Dificuldade deve come�ar em 1 para nao dividir o tempo de delay por zero.
char c=0;
int x, y, z; //Vari�veis que guardar�o o valor relativo da acelera��o em cada eixo.

char concluido = 0;
char data[6], string_auxiliar_de_impressao[4];

void SysTick_Handler(){
	cent_global++;
}

void getCommand(void){
	
	if(c == 0 || (PORTA_ISFR == 0 && toggle1 == 0)){	
		comando = 0;										
	}
	if(c == '1' || (PORTA_ISFR == 0 && toggle1 == 1)){	
		comando = 1;										
	}
	if(c == '2' || (PORTA_ISFR == 32 && toggle1 == 0)){
		comando = 2;
		if(!(GPIOA_PDIR & (1<<12))){
			while(!(GPIOA_PDIR & (1<<12)));
			flag6 = 1;
			comando = 6;
		}
	}
	if(c == '3' || (PORTA_ISFR == 4096 && toggle1 == 0)){
		comando = 3;
		if(!(GPIOA_PDIR & (1<<5))){
			while(!(GPIOA_PDIR & (1<<5)));
			flag6 = 1;
			comando = 6;
		}
	}
}

void NMI_Handler(){
	toggle1 = 1;
	getCommand();
	toggle1 = 0;
	return;
}

void PORTA_IRQHandler(){
	
	getCommand();
	
	PORTA_ISFR = (1<<5);
	PORTA_ISFR = (1<<12);

}

void UART0_IRQHandler(){
	c = getchar_UART0();
	getCommand();
	c=0;
}

void InitAcel(void) {
	I2CWriteRegister(ACCEL_I2C_ADDRESS, CTRL_REG2, 0x40);
	while(I2CReadRegister(ACCEL_I2C_ADDRESS, CTRL_REG2) & 0x40);
	I2CWriteRegister(ACCEL_I2C_ADDRESS, XYZ_DATA_CFG, (I2CReadRegister(ACCEL_I2C_ADDRESS, XYZ_DATA_CFG)&0xec));
	I2CWriteRegister(ACCEL_I2C_ADDRESS, CTRL_REG2, (I2CReadRegister(ACCEL_I2C_ADDRESS, CTRL_REG2)&0xec));
	I2CWriteRegister(ACCEL_I2C_ADDRESS, CTRL_REG1, (I2CReadRegister(ACCEL_I2C_ADDRESS, CTRL_REG1) | 0x39));
}

int signedChar_to_Int(int x){//Corrige um int que recebeu um signed char para um int equivalente.
	
	if(x & (1<<7)){//Verifica se o s�timo bit � positivo ou negativo, para se obter se o n�mero original era positivo ou negativo.
		x -= (1<<7);//Zeramos o bit que SERVIA para identificar o sinal.
		x = 0b1111111 - (x-1);//Se era negativo, devemos fazer o complemento de dois invertido antes de mais nada.
		x = -x;//Obtemos agora o n�mero negativo real que possu�amos.
	}
	
	return x;
}

void shift_obstaculo(int array0[], int array1[]){//Atualiza o arraqy de obst�culos para a esquerda.
	
	int i=0;
	
	clear();
	setString(" ",1,0);
	j = ++j%16;
	for(i=0; i<16; i++){
		if(array0[(i + j)%16]==1){setPos(0, i); setChar('|');}
		if(array1[(i + j)%16]==1){setPos(1, i); setChar('|');}
	}
	
}

int check_colision(int n, int array0[], int array1[]){//Verifica se o usu�rio colidiu com um dos obst�culos.
	if((n==1 && array1[j]==1) || (n==0 && array0[j]==1 )){//Se a posi��o atual do usu�rio possuir um obst�culo, informe.
		if(n==1){setString("X",1,0);delay10us(100000);}
		if(n==0){setString("X",0,0);delay10us(100000);}
		return 1;
	}
	
	return 0;//Se nao h� obst�culos ali, retorne negativo para a colis�o.
	
}

void coloca_obstaculos(int array0[], int array1[]){//Gera��o de n�meros pseudoaleat�rios atrav�s da contagem do SysTick para decidir onde teremos obst�culos.
	array0[15] = 0; array1[15] = 0;
	
	if(SYST_CVR%2==0){//Metade dos m�ltiplos de 2 � tamb�m m�ltiplo de 4.
		if(SYST_CVR%4<=1 && array1[14]==0){//Cria obst�culo em cima.
			array0[15] = 1;
			
		}else if(array0[14]==0){//Cria obst�culo embaixo.
			array1[15] = 1;
		}
	}
}

void atualiza_monstro(){
	
	if(x>=-30){//linha de cima
		
		linha_atual = 0;//linha de cima
		
	}
	
	if(x<=-45){//linha de baixo
		
		linha_atual = 1;//linha de baixo.
		
	}
	
	if(!linha_atual){
		if(boca = 1- boca){//Usa pra abrir e fechar a boca do monstro
			
			setPos(0,0);//insere o caracter especial 1.
			setChar(0x01); 
			
		}else{//Se for �mpar, exibe-o de boca aberta.

			setPos(0,0);//insere o caracter especial 2.
			setChar(0x03); 

		}
		
	}else{
		
		if(boca = 1- boca){//Usa pra abrir e fechar a boca do monstro

			
			//insere o caracter especial 1.
			
			setPos(1,0);
			setChar(0x01); 
			
		}else{//Se for �mpar, exibe-o de boca aberta.

			
			//insere o caracter especial 2.
			setPos(1,0);
			setChar(0x03); 
			
		}
	}
}

void pontua_leds(int pontos){
	GPIOC_PDOR = pontos;//Apresenta o valor n em bin�rio nos leds.
	GPIOC_PSOR = (1<<10); // pulsa LE (Latch Enable) do 74573, em 1 (set)
	GPIOC_PCOR = (1<<10); // em 0 (clear)
}

void aciona_acelerometro(){
//======ATUALIZA DADOS DO ACELER�METRO E P�E NO TERMINAL==============================================================================================
	
	while(!concluido) {//ACCEL_I2C_ADDRESS � o endere�o do SLAVE.
		concluido = (I2CReadRegister(ACCEL_I2C_ADDRESS, STATUS) & 0x08); // Bit 3, dados prontos
	}
	concluido = 0;
	
	I2CReadMultiRegisters(ACCEL_I2C_ADDRESS, OUT_X_MSB, 6, data);//O array precisa ter 6 posi��es para guadar MSB e LSB dos eixos x,y e z.
	
	x = signedChar_to_Int(data[0]); // Os dados v�m em complemento de dois, por isso � necess�rio convert�-los antes de imprimir.
	y = signedChar_to_Int(data[2]); // Utilizamos os �ndices de dois em dois pois utilizaremos somente os dados de MSB e nao dos LSB.
	z = signedChar_to_Int(data[4]);

	
	
	
//=========================================================================================================================
}


int main(void){
	

	int obstaculos1[] = {0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0}; //Array que guardar� a posi��o dos obst�culos no LCD na parte de cima.
	int obstaculos2[] = {0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0}; //Array que guardar� a posi��o dos obst�culos no LCD na parte de baixo.
	
	
//Fazendo toda a inicializa��o de Hardware necess�ria.
	initI2C();
	init_UART0();
	InitAcel();
	inicGPIO();
	inicLCD(2);
	
	PORTA_PCR4 = 0x100;
	PORTA_PCR5 = 0x100;
	PORTA_PCR12 = 0x100;
	
	GPIOA_PDDR &= 0xFFFFEFCF;//Zera os bits 12, 5 e 4.	
	
	PORTA_PCR5 = (0x100);
	PORTA_PCR5 |= (1<<19);
	PORTA_PCR5 |= (1<<16);
	PORTA_PCR12 = (0x100);
	PORTA_PCR12 |= (1<<19);
	PORTA_PCR12 |= (1<<16);
	PORTA_PCR4 = 0x0700;
	NVIC_ISER = (1<<30); //Habilita interrup��o na Porta A e na UART0.
	NVIC_ISER |= (1<<12);
	UART0_C2 |= (1<<5);//Habilita interrup��o de RECEP��O de caracteres na UART0.
	
	
//Iniciando temporiza��o atrav�s do Systick.
	SYST_RVR=210429;//Quantidade adequada para a interrup��o ocorrer a cada 10ms (verificado no oscilosc�pio).
	SYST_CVR=0;//Passa qualquer valor para CVR, o que faz isso voltar a zero e recarregar o valor a partir de RVR.
	SYST_CSR= 0b111;//Seta o registrador de controle para receber clock da CPU, lan�ar a exce��o do systic e come�ar a contagem (respectivamente aos bits desta palavra).
	
	
//==========CARACTERES ESPECIAIS===========================================================================================
	clear();//Limpando o LCD para come�armos.
	
	delay10us(4);
	passaComando(0x48);
	delay10us(4);
			
	setChar( 0b00100); // Criando primeiro caractere especial.
	setChar( 0b01110); //Monstro de boca fechada.
	setChar( 0b11111);
	setChar( 0b10101);
	setChar( 0b11111);
	setChar( 0b01010);
	setChar( 0b01110);
	setChar( 0b10101);
	
	delay10us(4);
	passaComando(0x58);
	delay10us(4);
	
	setChar( 0b00100); // Criando primeiro caractere especial.
	setChar( 0b01110); //Monstro de boca aberta.
	setChar( 0b11111);
	setChar( 0b10101);
	setChar( 0b11111);
	setChar( 0b10001);
	setChar( 0b10001);
	setChar( 0b11111);
	
	delay10us(4);
	
//=========================================================================================================================	
	while(1){
		
		
		setString("Dificuldade:",0,0);
		setString("- <-PRESS S1-> +",1,0);
		
		puts_UART0("\n\n\n\n\n\n\n\n\n\n\n\r");
		puts_UART0("Incline a placa para os lados para aumentar ou diminuir a dificuldade. \n\n\rPressione S1 para continuar. \n\r");
		puts_UART0("S1 = Continue, S2 = Pause, S3 = Restart.\n\r");
		
		GPIOC_PDOR = 0;//zera os leds ao reiniciar o jogo.
		GPIOC_PSOR = (1<<10); // pulsa LE (Latch Enable) do 74573, em 1 (set)
		GPIOC_PCOR = (1<<10); // em 0 (clear)
		
		cent_global=hora_da_ultima_atualizacao=j=pontuacao=0;
			
		while(comando!=1){
			aciona_acelerometro();
			
			setPos(0,12);
			setChar('0' + dificuldade);
			
			if(y>=10 && dificuldade > 1){
				dificuldade--;
			}
			if(y<=-10 && dificuldade < 9){
				dificuldade++;
			}
			
			delay10us(50000);
		}
		
		while(1) {//Ciclo de repeti��es indeterminadas do programa.
			
			aciona_acelerometro();
			
			puts_UART0("                                           \r");
			puts_UART0("Acelerometro: ");
			int2ascii10(x, string_auxiliar_de_impressao);//Converte os dados do aceler�emetro para String e os exibe na tela
			puts_UART0(string_auxiliar_de_impressao);
			puts_UART0(", ");
			int2ascii10(y, string_auxiliar_de_impressao);
			puts_UART0(string_auxiliar_de_impressao);
			puts_UART0(", ");
			int2ascii10(z, string_auxiliar_de_impressao);
			puts_UART0(string_auxiliar_de_impressao);
			putchar_UART0('\r');
			
		
//======IDENTIFICA COMANDO DO USUARIO==============================================================================================					
			
			if(comando==1){SYST_CSR = 0b111; comando = 0;}//Se pressionar o bot�o 1, continue o jogo.
			
			if(comando==2){SYST_CSR = 0b110;hora_da_ultima_atualizacao=cent_global; setString("-----PAUSE------",1,0); setString("-----PAUSE------",0,0);comando = 0;}//Se pressionar o bot�o 2, pause o jogo.
			
			if(comando==3){cent_global=hora_da_ultima_atualizacao=j=pontuacao=0; comando = 0; clear(); break; }//Se pressionar o bot�o 3, reinicie o jogo.
			
//=================================================================================================================================			
			
			
			
			
			
//======INTERATIVIDADE COM O USU�RIO=============================================================================================	
		 
			if(cent_global - hora_da_ultima_atualizacao >= 300/dificuldade){//Se obtivemos um delay adequado j� (mas sem travar o programa)...
				hora_da_ultima_atualizacao = cent_global;
				
				pontuacao++;//Deve-se acrescentar assim a pontua��o para que o SysTick nao a influencia ap�s continuar contando mesmo em pause.
				
				shift_obstaculo(obstaculos1, obstaculos2);
				atualiza_monstro();
				pontua_leds(pontuacao/10);
				
				if(check_colision(linha_atual, obstaculos1, obstaculos2)){//Se houver colis�o, exibe a derrota na tela e trava o programa at� reiniciar.
					setString("S3 reinicia jogo",1,0);
					setString("Pontos:        ",0,0);
					int2ascii10(pontuacao/10, string_auxiliar_de_impressao);//A cada dez segundos marca-se um ponto.
					setString(string_auxiliar_de_impressao,0,7);//Exibe a pontua��o na tela
					while(comando!=3);//Aguarda botao de rein�cio ser pressionado.
				}
				
			}
			
			if(pontuacao/10 >= 0xFF){clear(); setString("DEUS DA VITORIA!",0,0); delay10us(1500000); cent_global=hora_da_ultima_atualizacao=j=pontuacao=0; comando = 0; clear(); break; } //Se atingirmos o limite da contagem, reinicie o cron�metro e parabenize o usu�rio.
//=================================================================================================================================
			
		}
	}
}

