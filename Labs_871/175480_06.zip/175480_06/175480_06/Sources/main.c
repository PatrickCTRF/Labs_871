#include "derivative.h" /* include peripheral declarations */
#include "LiquidCrystal.h"

int main(void){
	
	int i=0;
	
	inicGPIO();
	inicLCD(2);
	
	passaComando(0x40);
	delay10us(4);
			
			
	setChar( 0b00000); // Criando primeiro caractere especial.
	setChar( 0b00000); //Parte de tr�s do navio.
	setChar( 0b11111);
	setChar( 0b01000);
	setChar( 0b00111);
	setChar( 0b00000);
	setChar( 0b00000);
	setChar( 0b00000);

	 passaComando(0x60);
	 delay10us(4);
	 
	 setChar( 0b00000); // Criando segundo caractere especial.
	 setChar( 0b00000); //Parte da frente do navio.
	 setChar( 0b11111);
	 setChar( 0b00010);
	 setChar( 0b11100);
	 setChar( 0b00000);
	 setChar( 0b00000);
	 setChar( 0b00000);
	
//====ATIVIDADE_1================================================================================================================================	
	setString("175480",0,0);
	setPos(1,11);
	setString("EA871",1,11);
	delay10us(500000);
	clear();
//====ATIVIDADE_1================================================================================================================================

//====ATIVIDADE_2================================================================================================================================		
	
//A atividade 2 tenta representar um navio soltando fum�a pela chamin� e indo para o lado.
	
	while(1)
		for(i=0; i<11; i++){
			
			setPos(0,i); //Fuma�a da chamin�
			setString("Oo",0,i+1);
			
			
			setPos(1,i);
			setChar( 0x00); //Parte debaixo do NAVIO.
			setString("=''=",1,i+1);
			setPos(1,i+5);
			setChar( 0x04);
			
			delay10us(50000);
			clear();
			
		};
//====ATIVIDADE_2================================================================================================================================	
	
	return 0;
}
