/*
 * LCD.c
 *
 *  Created on: Sep 28, 2016
 *      Author: ea871
 */


#include "LCD.h"
#include "derivative.h" /* include peripheral declarations */

#define clearCMD 0b0000000001
#define posInicial 0b0000000010
#define oneLineMode 0b0000110111
#define twoLineMode 0b0000111111


void inicGPIO(){
	SIM_SCGC5 |= 0x00000800; // Ativa clock da PORTC.

	PORTC_PCR0  = 0x00000100; // Configura pin MUX control what.
	PORTC_PCR1  = 0x00000100;
	PORTC_PCR2  = 0x00000100;
	PORTC_PCR3  = 0x00000100;
	PORTC_PCR4  = 0x00000100;
	PORTC_PCR5  = 0x00000100;
	PORTC_PCR6  = 0x00000100;
	PORTC_PCR7  = 0x00000100;
	PORTC_PCR8  = 0x00000100;
	PORTC_PCR9  = 0x00000100;
	PORTC_PCR10  = 0x00000100;

	GPIOC_PDDR 	= 0x000007FF; // Dez primeiros terminais de PDDR s�o sa�das.
	GPIOC_PDOR 	&= 0xFFFFF800; // Zerando os terminais que ser�o utilizados aqui.
}

void delay10us(int n){
	n *= 21;	// 10*n em microsegundos, aproximadamente
			
	while(n>0) n--;
}

void inicLCD(int qtsLinhas){
	
	delay10us(3001); // Tempo para o display ser energizado.
	
	if(qtsLinhas==1){ // Se for desejado somente uma linha...
		passaComando(oneLineMode);
	}else { // Se forem duas entao...
		passaComando(twoLineMode);
	}
	delay10us(4); // 39ms para garantir que o display recebeu e se desocupou da opera��o.
	
	passaComando(0b0000001100);// Comando para deixar o display no modo ON e o cursor no modo OFF.
	delay10us(4);
	
	clear(); //Limpa o display conforme requisitado.
	passaComando(posInicial); //Retorna o cursor ao in�cio da tela.
	delay10us(154); // Delay de 1,53ms.
}

void passaComando(unsigned int comando){
	GPIOC_PDOR	|= (1<<9)|(1<<8); // Enable em n�vel alto.
	GPIOC_PCOR	= (1<<8); // PTC8 valendo zero para utilizar o modo comando.
	GPIOC_PDOR 	&= 0xFFFFFF00; // Zera os bits nos quais ser� salvo o comando requisitado.
	GPIOC_PDOR	|= comando; //Guarda o comando nos oito primeiros bits.
	GPIOC_PCOR	= (1<<9); //Reseta o terminal de Enable para podermos prosseguir a execu��o do LCD.
}

void clear(){ //clear display
	passaComando(clearCMD); 					
	delay10us(154); //aguarda 1,53ms.
}

void setString(char frase[], int linha, int coluna){
	
	setPos(linha, coluna); //Move o cursos � posi��o desejada.
	
	int i=0;
	while(frase[i]){
		setChar(frase[i++]); // Utiliza o caractere e j� passa ao pr�ximo.
   }
}

void setChar(char caractere){
	GPIOC_PDOR	|= (1<<9)|(1<<8); // Enable em n�vel alto e PTC8 valendo 1 para utilizar o modo comando.
	GPIOC_PDOR 	= (GPIOC_PDOR & 0xFFFFFF00) | caractere; // Passa o caractere.
	GPIOC_PCOR	= (1<<9); // Retorna enable para o n�vel baixo.
	delay10us(4); // 39ms.
}

void setPos(int linha, int coluna){
	
	int aux=0;							
	
	if (linha == 1) aux=0x40;//0x40 para escrever na segunda linha.
		
	aux += coluna; // Define a coluna desejada.
	aux += 0b0010000000; // SET DD.
	
	passaComando(aux);
	
	delay10us(4);// aguarda 39ms.
}

void shift_left(){//Desloca os caracteres do LCD � esquerda.
	passaComando(0x18);
	delay10us(82);
}

void shift_right(){//Desloca os caracteres do LCD � direita.
	passaComando(0x1C);
	delay10us(82);
}
