/*
 * prog7.c
 *
 *  Created on: Sep 28, 2016
 *      Author: ea871
 */

//175480_07

#include "UART.h"
#include "LCD.h"

int main(void){
	
	inicGPIO();//Fazendo toda a inicializa��o de software necess�ria.
	inicLCD(2);
	init_UART0();
	
	char decimal[5] = "1234", hexa[5] = "1234", c;
	
	puts_UART0("Bem Vind@ 175480 \r\nDigite caracteres:\r\n");// Exibe a string inicial.
	
	clear();//Limpa o lcd.
	
	while(1){
		c = getchar_UART0();//Recebe o caracter digitado.
		putchar_UART0(c);//Exibe o caracter no terminal.
		clear();//Limpa o lcd.
		
		setPos(0, 0);//Escreve o caracter recebido na posi��o inicial.
		if (c >= 32 && c < 127){	
			setChar(c);
		} else {
			setChar(' ');
		}
		
		setPos(1, 0);//Escreve a string hexa em seu devido lugar.
		int2ascii16(c, hexa);
		setString(hexa, 1, 0);
		
		setPos(0, 12);//Escreve a string decimal em seu devido lugar.
		int2ascii10(c, decimal);
		setString(decimal, 0, 12);
	}
	
	return 0;
}
