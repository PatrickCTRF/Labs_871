/*
 * P�ginas importante do datasheet do aceler�metro:
 * 
 * I2C data sequence diagrams - 19;
 * 
 *Table 11. I2C device address sequence - 18 
 * 
 * Register Descriptions (ENDERE�OS FUNDAMENTAIS) - 20
 * 
 * 
 * P�gina mais importante do manual do KL25:   692.
 */




#include "derivative.h"
#include "i2c.h"

void initI2C(void)
{
  SIM_SCGC5 = SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTE_MASK;
  SIM_SCGC4 |= SIM_SCGC4_I2C0_MASK;
  PORTE_PCR24 = PORT_PCR_MUX(5);
  PORTE_PCR25 = PORT_PCR_MUX(5);
  I2C0_F |= I2C_F_MULT(0) | I2C_F_ICR(0x14) ; 
  I2C0_C1 = I2C_C1_IICEN_MASK;
  //Configure the PTA14 pin (connected to the INT1 of the MMA8451Q) for falling edge interrupts
  PORTA_PCR14 |= (0|PORT_PCR_ISF_MASK|	// Clear the interrupt flag 
  					  PORT_PCR_MUX(0x1)|	// PTA14 is configured as GPIO 
  					  PORT_PCR_IRQC(0xA));	// PTA14 is configured for falling edge interrupts 
  PORTA_PCR15 |= (0|PORT_PCR_ISF_MASK|	// Clear the interrupt flag 
    					  PORT_PCR_MUX(0x1)|	// PTA15 is configured as GPIO 
    					  PORT_PCR_IRQC(0xA));	// PTA15 is configured for falling edge interrupts 
}
                                  
/* Inicia Transmissao I2C
 * SlaveID: endereco do slave
 * "Mode" define modo Read (1) ou Write (0)
 */
void IIC_StartTransmission (char SlaveID, char Mode)
{
  SlaveID = SlaveID << 1;//Este shift e a soma com 1 � paraobtermos o valor da tabela Table 11. I2C device address sequence para 8 bits.
  SlaveID |= (Mode & 0x01);
  i2c_Start(); // Sinal de start para a transmiss�o come�ar. Salvo no MASTER.
  i2c_write_byte(SlaveID);//Registrador o qual se deseja analisar.
}

void Pause(void){
    int n;
    for(n=1;n<50;n++) {
      asm("nop");
    }
}

/* Le um registrador do slave I2C
 * SlaveID: endereco do slave
 * RegisterAddress: endereco do registrador interno do slave
 * Retorna o valor do registrador
 */
char I2CReadRegister(char SlaveID, char RegisterAddress)
{
  char result;

  IIC_StartTransmission(SlaveID,MWSR);
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_write_byte(RegisterAddress); //Escrevo no MASTER de quem eu quero ler.
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_RepeatedStart(); // Continua transmissao sem interromp�-la.
  i2c_write_byte((SlaveID << 1) | 0x01); //Fa�o a convers�o para 8 bits da Table 11.
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_EnterRxMode(); // Entra no modo de recep��o dos dados
  i2c_DisableAck(); // Desabilita ACK por ser o penultimo byte a ler
  result = I2C0_D ; // Leitura modelo
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_Stop(); // Envia STOP por ser o ultimo byte
  result = I2C0_D ; // Le o byte
  Pause(); // Aguarda por recomenda��o do manual.
  return result;
}

/* Escreve um byte no registrador interno do slave I2C
 * SlaveID: endereco do slave
 * RegisterAddress: endereco do registrador interno do slave
 * Data: Valor a escrever
 */
void I2CWriteRegister(char SlaveID, char RegisterAddress, char Data)
{
  IIC_StartTransmission(SlaveID,MWSR);
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_write_byte(RegisterAddress);//Escrevo no MASTER de quem eu quero ler.
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_write_byte(Data);//Seta a sensibilidade ou a taxa de transmiss�o.
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_Stop();//Encerra a transmissao.
  Pause(); // Aguarda por recomenda��o do manual.
}

/* Le "N" registradores internos do slave I2C
 * SlaveID: endereco do slave
 * RegisterAddress: endereco do primeiro registrador interno do slave a ser lido
 * n: Numero de registradores a serem lidos em sequencia
 * Resultado armazenado no ponteiro *r
 */
void I2CReadMultiRegisters(char SlaveID, char RegisterAddress, char n, char * r)
{
  char i;

  IIC_StartTransmission(SlaveID,MWSR);
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_write_byte(RegisterAddress);
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_RepeatedStart();
  i2c_write_byte((SlaveID << 1) | 0x01);
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.
  i2c_EnterRxMode();// Entra no modo de recep��o dos dados
  i2c_EnableAck();// Habilita ACK por ser seguido de v�rios byte a ler
  i = I2C0_D ; // Leitura modelo.
  i2c_Wait();// O wait espera que o SLAVe set a flag AK avisando que j� obteve os dados.

  for(i=0;i<n-2;i++) // le n-1 bytes somente pois a seguir precisamos desabilitar AK para encerrar a transmiss�o
  {
    *r = I2C0_D;
    r++;
    i2c_Wait();
  }
  
  i2c_DisableAck(); // Desabilita ACK por ser o penultimo byte a ler
  *r = I2C0_D; // Le penultimo byte
  r++;
  i2c_Wait();
  i2c_Stop(); // Envia STOP por ser o ultimo byte
  *r = I2C0_D; // Le ultimo byte
  Pause();
}

