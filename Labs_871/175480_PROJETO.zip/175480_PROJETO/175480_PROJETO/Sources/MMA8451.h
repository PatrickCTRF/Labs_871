/*
 * MMA8451.h
 *
 *  Created on: Nov 28, 2014
 *      Author: Gudwin
 */

#ifndef MMA8451_H_
#define MMA8451_H_
#define ACCEL_I2C_ADDRESS 0x1D
#define STATUS 0x00
#define OUT_X_MSB 0x01
#define WHO_AM_I 0x0D
#define XYZ_DATA_CFG 0x0E
#define CTRL_REG1 0x2A
#define CTRL_REG2 0x2B
#define CTRL_REG4 0x2D
#define CTRL_REG5 0x2E

#endif /* MMA8451_H_ */

