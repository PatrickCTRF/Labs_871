/*
 * UART.c
 *
 *  Created on: Sep 28, 2016
 *      Author: ea871
 */

#include<derivative.h>

void init_UART0(void){//fun��o que inicializa a opera��o da UART0 (GPIO, MUX e Clock - consulte os ap�ndices 3 e 4).
	
	SIM_SCGC4 |= 0x400; // (1<<10) //� necess�rio escrever esta valor neste registrador pois o d�cimo primeiro pino (ou bit 10) � respons�vel por habilitar o clock do UART0. 
	SIM_SCGC5 |= 0x200; // (1<<9) //� necess�rio escrever esta valor neste registrador pois o d�cimo pino (ou bit 9) � respons�vel por habilitar o clock do UART0.
	
	PORTA_PCR1 = 0x200; // (1<<9) //Ativa o MUX para executar a op��o "alternative 2" (ALT2), que � a que liga o pino controlado por este (PTA1) registrador ao UART.
	PORTA_PCR2 = 0x200; // (1<<9) //Ativa o MUX para executar a op��o "alternative 2" (ALT2), que � a que liga o pino controlado por este (PTA2) registrador ao UART.
	
	SIM_SOPT2 = (1<<26); // Coloca o vig�simo s�timo bit (28� pino) em alto, para selecionar o modo MCGIRCLK de clock para UART0.
	
	// UART0_BDH |= 0x1; Afinal, isto n�o era necess�rio...
	UART0_BDL = 0x45;
	
	//UART0_C4 = 0xF; tamb�m � desnecess�rio.
	
	UART0_C2 = 0xC; //Seta os bit transmission enable (TE) e read enable (RE).
}

char getchar_UART0(void){//fun��o que recebe um caractere da UART0.
	char c = '\0';
	
	while( !(UART0_S1 & UART0_S1_RDRF_MASK));//Aguarda um caracter a ser lido...
	
		c = UART0_D; // Recebe o caracter.
	
	return c; //Devolve o caracter lido, se houver.
	
}

void putchar_UART0(char c){//fun��o que envia um caractere pela UART0.
	
	while( !(UART0_S1 & UART0_S1_TDRE_MASK)); // Aguarda o registrador estar livre para receber o caracter.
	UART0_D = c; // O caracter � passado ao registrador.
	
}

void puts_UART0(char *c){//fun��o que envia uma cadeia de caracteres (string) pela UART0.
	
	int i=0;
	
	for(i=0; c[i] != '\0'; i++)putchar_UART0(c[i]);//Envia, caracter por caracter, a frase para o UART.
	
}

//Embora a entrada n�o possa ser negativa, trataram-se estes casos para fins de contorno de poss�veis erros e devido aos coment�rios do ap�ndice 5.
void int2ascii10(int mosa, char *s){
	if(mosa == 0){ s[0] = '0'; s[1] = '\0'; return;}//Se for zero, j� retorne a string zero.
	
	int i = 0, tam = 0, aux = 0;
	
	int j = mosa>=0 ? 0 : 1;//Descobrindo se mosa � positivo ou negativo.
	
	s[0] = '-';//Se o n�mero for negativo, todas as casas ser�o deslocadas � direita e este caracter representar� o sinal de menos.
		
	if(j){mosa = -mosa;}
	
	for(i = 0; mosa>0; i++){
		s[i+j] =(char)( mosa%10 + '0');
		mosa /= 10;
	}
	
	tam = i;
	
	for(i = 0; tam/2>i; i++){
		aux = s[tam - i -1 + j];
		s[tam - i -1 + j] = s[i + j];
		s[i + j] = aux;
	}
	
	s[tam+j] = '\0';
	
}

//Embora a entrada n�o possa ser negativa, trataram-se estes casos para fins de contorno de poss�veis erros e devido aos coment�rios do ap�ndice 5.
void int2ascii16(int mosa, char *s){
	if(mosa == 0){ s[0] = '0'; s[1] = '\0'; return;}//Se for zero, j� retorne a string zero.
	
	int j = 0, tam = 0, aux = 0;
	int i = mosa>=0 ? 0 : 1;//Descobrindo se mosa � positivo ou negativo.
	
	char ref[] = "0123456789ABCDEF";
	
	s[0] = '-';//Se o n�mero for negativo, todas as casas ser�o deslocadas � direita e este caracter representar� o sinal de menos.
	
	if(i){mosa = -mosa;}
	
	//Consulta-se no array de refer�ncia qual o caracter adequado a cada valor, substituindo-o na string.
	for(j = 0; mosa>0; j++){
			s[j+i] = ref[mosa%16];
			mosa /= 16;
		}
	
	tam = j;
		
	for(i = 0; tam/2>i; i++){
		aux = s[tam - i -1 + i];
		s[tam - i -1 + i] = s[i + i];
		s[i + i] = aux;
	}
	
	s[j+i] = '\0';
	
}
