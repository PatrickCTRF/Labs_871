/*
 * UART.h
 *
 *  Created on: Sep 28, 2016
 *      Author: ea871
 */

#ifndef UART_H_
#define UART_H_

void init_UART0(void); //fun��o que inicializa a opera��o da UART0 (GPIO, MUX e Clock - consulte os ap�ndices 3 e 4).

char getchar_UART0(void); //fun��o que recebe um caractere da UART0.

void putchar_UART0(char); //fun��o que envia um caractere pela UART0.

void puts_UART0(char *); //fun��o que envia uma cadeia de caracteres (string) pela UART0.

void int2ascii10(int mopa, char *s);

void int2ascii16(int mopa, char *s); 

#endif /* UART_H_ */
