//175480_11

#include "UART.h"
#include "LCD.h"
#include"derivative.h"

#define NMAX 1024

#define HR (n[n[0]]/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MIN ((n[n[0]]%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEG (((n[n[0]]%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENT (((n[n[0]]%360000)%6000)%100) //Cent�simos.

#define HRlap (n[i]/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MINlap ((n[i]%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEGlap (((n[i]%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENTlap (((n[i]%360000)%6000)%100) //Cent�simos.

volatile int cent_global = 0, toggle1 = 0, toggle2 = 0, toggle3 = 0, comando = 0, flag4 = 0, flag5 = 0, flag6 = 0, buffer[NMAX] = {0}, n_buffer = NMAX/2, pi = 0, po = 0;
volatile char c=0, aux = 'P';

void getCommand(void);

void lap(int, int*, int);

void SysTick_Handler(){
	cent_global++;
}

void putchar(char c){
	UART0_C2 = 0x8C;//Habilita interrup��o de TRANSMISS�O de caracteres na UART0.
	
	while(!(n_buffer < NMAX));//Enquanto o buffer n�o possuir espa�os livres, aguarde.
	
	UART0_C2 = 0x2C;//Habilita interrup��o somente de RECEP��O de caracteres na UART0, pois agora n�o precisamos mais transmitir.
	
	buffer[pi++] = c;//Acrescenta o elemento no buffer e adianta o apontador em seguida.
	++n_buffer;//Acrescenta 1 ao contador de bytes no buffer, indicando que a a��o foi realizada.
	pi %= NMAX;//Verifica se o apontador pi atingiu o limite do buffer e, caso positivo, retorna-o ao in�cio do buffer, j� que � um buffer circular.
	
	UART0_C2 = 0x2C;//Habilita interrup��o de TRANSMISS�O de caracteres na UART0.
}

void puts_buffer(char *c){//fun��o que envia uma cadeia de caracteres (string) pela UART0 atrav�s do buffer.
	
	int i=0;
	
	for(i=0; c[i] != '\0'; i++)putchar(c[i]);//Envia, caracter por caracter, a frase para o buffer da UART.
	
}

void UART0_IRQHandler(){
	
	
	
	if(UART0_S1 & UART0_S1_RDRF_MASK){
		c = getchar_UART0();
		getCommand();
		c = 0;
	}
	
	if((UART0_S1 & UART0_S1_TDRE_MASK)&&n_buffer>0){//S� executa esta parte se houve uma interrup��o de Transmiss�o e o buffer possui algo a se transmitir.
		aux = buffer[po++];//Obt�m o elemento do buffer e adianta o apontador em seguida.
		--n_buffer;//Subtrai 1 do contador de bytes no buffer, indicando que a a��o foi realizada.
		po %= NMAX;//Verifica se o apontador po atingiu o limite do buffer e, caso positivo, retorna-o ao in�cio do buffer, j� que � um buffer circular.
		putchar_UART0(aux);
	}
	
	UART0_D = '\0';//Esta linha se faz necess�ria por algum motivo n�o evidente. Creio que seja por zerar a flag TDRE e cancelar a prox�ma chamada de TDRE.
}

void getCommand(void){
	
	if(c == 0 || (PORTA_ISFR == 0 && toggle1 == 0)){	
		comando = 0;										
	}
	if(c == '1' || (PORTA_ISFR == 0 && toggle1 == 1)){	
		comando = 1;										
	}
	if(c == '2' || (PORTA_ISFR == 32 && toggle1 == 0)){
		comando = 2;
		if(!(GPIOA_PDIR & (1<<12))){
			while(!(GPIOA_PDIR & (1<<12)));
			flag6 = 1;
			comando = 6;
		}
	}
	if(c == '3' || (PORTA_ISFR == 4096 && toggle1 == 0)){
		comando = 3;
		if(!(GPIOA_PDIR & (1<<5))){
			while(!(GPIOA_PDIR & (1<<5)));
			flag6 = 1;
			comando = 6;
		}
	}
	if(c == '4' || (toggle1 == 1 && !(GPIOA_PDIR & (1<<5)))){
		while(!(GPIOA_PDIR & (1<<5)));
		comando = comando*1;//Aguardo
		flag4 = 1;
		comando = 4;
		
	}
	if(c == '5' || (toggle1 == 1 && !(GPIOA_PDIR & (1<<12)))){
		while(!(GPIOA_PDIR & (1<<12)));
		comando = comando*1;//Aguardo
		flag5 = 1;
		comando = 5;
		
	}
	if(c == '6'){
		flag6 = 1;
		comando = 6;
	}
}



void NMI_Handler(){
	toggle1 = 1;
	getCommand();
	toggle1 = 0;
	return;
}

void PORTA_IRQHandler(){
	
	getCommand();
	
	PORTA_ISFR = (1<<5);
	PORTA_ISFR = (1<<12);
	
}


int main(void){
	
	
	
//======TODA A PARTE DE INICIALIZA��O=====================================================================================================================
	
	inicGPIO();//Fazendo toda a inicializa��o de software necess�ria.
	inicLCD(2);
	init_UART0();
	
	PORTA_PCR4 = 0x100;
	PORTA_PCR5 = 0x100;
	PORTA_PCR12 = 0x100;
	
	GPIOA_PDDR &= 0xFFFFEFCF;//Zera os bits 12, 5 e 4, configurando-os como input.
		
	
	PORTA_PCR5 = (0x100);
	PORTA_PCR5 |= (1<<19);
	PORTA_PCR5 |= (1<<16);
	PORTA_PCR12 = (0x100);
	PORTA_PCR12 |= (1<<19);
	PORTA_PCR12 |= (1<<16);
	PORTA_PCR4 = 0x0700;
	NVIC_ISER = (1<<30); //Habilita interrup��o na Porta A e na UART0.
	NVIC_ISER |= (1<<12);
	UART0_C2 = 0x2C;//Habilita interrup��o de RECEP��O de caracteres na UART0.
		
	
	puts_buffer("\r\n");// Ajusta o terminal para uma linha limpa.
	
	clear();//Limpa o lcd.
	
	SYST_RVR=210429;//Quantidade adequada para a interrup��o ocorrer a cada 10ms (verificado no oscilosc�pio).
	SYST_CVR=0;//Passa qualquer valor para CVR, o que faz isso voltar a zero e recarregar o valor a partir de RVR.
	SYST_CSR= 0b110;//Seta o registrador de controle para receber clock da CPU, lan�ar a exce��o do systic e n�o come�ar a contagem (respectivamente aos bits desta palavra).

//======FIM DA PARTE DE INICIALIZA��O=====================================================================================================================
	
	
	
	
	//int cent_global = 0; // Guarda os cent�simos de segundo.
	int i=0; //Vari�vel marcadora de posi��o.
	int b1 = 0, b1old = 0, b2 = 0, b2old = 0, b3 = 0, b3old = 0, laps[4] = {0};// b1 == start/pause, b2 == reset, b3 == lap.
	unsigned int pta4, pta5, pta12;
	char c = 0;
	int hr=0, min=0, seg=0, cent=0;
	char n_buffer_em_char[6] = {0};
	
	n_buffer_em_char[4] = ' ';
	n_buffer_em_char[5] = '\0';
	
	while(1){ //Daqui para frente o c�digo se repete at� o desligamento da placa.
		
		
		
		cent = (((cent_global%360000)%6000)%100);//Obtendo os valores de interesse.
		if(cent==0 && cent_global){seg++; cent=0;}
		if(seg==60){min++; seg=0;}
		if(min==60){hr++; min=0;}
		
		
//======ESCREVENDO NO LCD=====================================================================================================================
		i=0;
		setPos(0, i);//Aponta o cursor na posi��o inicial.
		setString(n_buffer_em_char, 0, 0);
		
		i=5;
		setPos(0, i++);
		setChar(hr/10 + '0');//Exibe no LDC as horas transcorridas.
		setPos(0, i++);
		setChar(hr%10 + '0');//Exibe no LDC as horas transcorridas.
		
		setPos(0,i++);
		setChar(':');//Insere o separador.
		
		setPos(0, i++);
		setChar(min/10 + '0');//Exibe no LDC os minutos transcorridas.
		setPos(0, i++);
		setChar(min%10 + '0');//Exibe no LDC os minutos transcorridas.
		
		setPos(0, i++);
		setChar(':');//Insere o separador.
		
		setPos(0, i++);
		setChar(seg/10 + '0');//Exibe no LDC os segundos transcorridas.
		setPos(0, i++);
		setChar(seg%10 + '0');//Exibe no LDC os segundos transcorridas.
		
		setPos(0, i++);
		setChar('.');//Insere o separador.
		
		setPos(0, i++);
		setChar(cent/10 + '0');//Exibe no LDC os cent�simos transcorridas.
		setPos(0, i++);
		setChar(cent%10 + '0');//Exibe no LDC as cent�simos transcorridas.
		
		
		n_buffer_em_char[0]=(n_buffer/1000 + '0');
		n_buffer_em_char[1]=((n_buffer%1000)/100 + '0');
		n_buffer_em_char[2]=(((n_buffer%1000)%100)/10 + '0');
		n_buffer_em_char[3]=(((n_buffer%1000)%100)%10 + '0');
		
//======ESCRITO NO LCD========================================================================================================================

		
		
		
		
		
//======ESCREVENDO NO TERminAL=====================================================================================================================
		putchar('\r');//Retorna o caracter para o in�cio da linha para sobrescrev�-la.
		
		puts_buffer("Tempo ");
		
		putchar(hr/10 + '0');//Exibe no TERminAL as horas transcorridas.
		putchar(hr%10 + '0');//Exibe no TERminAL as horas transcorridas.
		
		putchar(':');//Insere o separador
		
		putchar(min/10 + '0');//Exibe no TERminAL os minutos transcorridas.
		putchar(min%10 + '0');//Exibe no TERminAL os minutos transcorridas.
		
		putchar(':');//Insere o separador
		
		putchar(seg/10 + '0');//Exibe no TERminAL os segundos transcorridas.
		putchar(seg%10 + '0');//Exibe no TERminAL os segundos transcorridas.
		
		putchar('.');//Insere o separador
		
		putchar(cent/10 + '0');//Exibe no TERminAL os cent�simos transcorridas.
		putchar(cent%10 + '0');//Exibe no TERminAL as cent�simos transcorridas.
		
		
//======ESCRITO NO TERMINAL========================================================================================================================
		
		
		
		if(flag4){comando = 4; flag4 = 0;}
		if(flag5){comando = 5; flag5 = 0;}
		if(flag6){comando = 6; flag6 = 0;}
		
		if(hr == 100) cent_global=0; //Se atingirmos o limite da contagem, reinicie o cron�metro.				
		
		if(comando==1){comando = 0; SYST_CSR = 0b111;}//Se pressionar o bot�o 1, pause o programa, pois para de atualizar o contador registrador de CVR (ativando ou desativando o primeiro pino do registrador de controle).
		
		if(comando==2){comando = 0; SYST_CSR = 0b110;}
		
		if(comando==3){hr=min=seg=cent=cent_global= 0;comando = 0;}//Se pressionar o bot�o 2, reinicie a contagem.
		
		if(comando==4){lap(cent_global, laps, 1);comando = 0;}//Se pressionar o bot�o 3, conte um lap.
		
		if(comando==5){lap(cent_global, laps, 2);comando = 0;}//Se pressionar o bot�o 3, conte um lap.
		
		if(comando==6){lap(cent_global, laps, 3);comando = 0;}//Se pressionar o bot�o 3, conte um lap.
		

	}
	
	
	return 0;
}

void lap(int cent_global, int *n, int numero){
	
	int i;//Esta vari�vel serve para marcar posi��o tanto no LDC quanto no terminal.
	
	n[0] = numero;//Selcionar qual � a LAP sendo usada.
	n[n[0]] = cent_global;//Guarda o valor do cent_global na flag devida
	
	
//======ESCREVENDO NO LCD=====================================================================================================================
		i=0;
		setPos(1, i);//Aponta o cursor na posi��o inicial.
		setString("LAP", 1, 0);
		
		i=3;
		setPos(1, i++);
		setChar(n[0] + '0');//Mostra qual a lap sendo exibida no lcd.
		setPos(1,i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(HR/10 + '0');//Exibe no LDC as horas transcorridas.
		setPos(1, i++);
		setChar(HR%10 + '0');//Exibe no LDC as horas transcorridas.
		
		setPos(1,i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(MIN/10 + '0');//Exibe no LDC os minutos transcorridas.
		setPos(1, i++);
		setChar(MIN%10 + '0');//Exibe no LDC os minutos transcorridas.
		
		setPos(1, i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(SEG/10 + '0');//Exibe no LDC os segundos transcorridas.
		setPos(1, i++);
		setChar(SEG%10 + '0');//Exibe no LDC os segundos transcorridas.
		
		setPos(1, i++);
		setChar('.');//Insere o separador.
		
		setPos(1, i++);
		setChar(CENT/10 + '0');//Exibe no LDC os cent�simos transcorridas.
		setPos(1, i++);
		setChar(CENT%10 + '0');//Exibe no LDC as cent�simos transcorridas.
//======ESCRITO NO LCD========================================================================================================================

		
		
		
		
		
//======ESCREVENDO NO TERMINAL=====================================================================================================================
	
		for(i=1; i<=n[0]; i++){
		
		puts_buffer(" LAP");
		
		putchar(i + '0');
		
		putchar(' ');
		
		putchar(HRlap/10 + '0');//Exibe no TERMINAL as horas transcorridas.
		putchar(HRlap%10 + '0');//Exibe no TERMINAL as horas transcorridas.
		
		putchar(':');//Insere o separador
		
		putchar(MINlap/10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		putchar(MINlap%10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		
		putchar(':');//Insere o separador
		
		putchar(SEGlap/10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		putchar(SEGlap%10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		
		putchar('.');//Insere o separador
		
		putchar(CENTlap/10 + '0');//Exibe no TERMINAL os cent�simos transcorridas.
		putchar(CENTlap%10 + '0');//Exibe no TERMINAL as cent�simos transcorridas.
		
	}
		
//======ESCRITO NO TERMINAL========================================================================================================================
		

}
