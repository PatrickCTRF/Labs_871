//175480_08

#include "UART.h"
#include "LCD.h"
#include"derivative.h"

#define HR (cs/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MIN ((cs%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEG (((cs%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENT (((cs%360000)%6000)%100) //Cent�simos.

#define HRlap (n[i]/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MINlap ((n[i]%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEGlap (((n[i]%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENTlap (((n[i]%360000)%6000)%100) //Cent�simos.

void lap(int, int*);

int main(void){
	
	
	
//======TODA A PARTE DE INICIALIZA��O=====================================================================================================================
	
	inicGPIO();//Fazendo toda a inicializa��o de software necess�ria.
	inicLCD(2);
	init_UART0();
	
	PORTA_PCR4 = 0x100;
	PORTA_PCR5 = 0x100;
	PORTA_PCR12 = 0x100;
	
	GPIOA_PDDR &= 0xFFFFEFCF;//Zera os bits 12, 5 e 4.
	
	puts_UART0("\r\n");// Ajusta o terminal para uma linha limpa.
	
	clear();//Limpa o lcd.

//======FIM DA PARTE DE INICIALIZA��O=====================================================================================================================
	
	
	
	
	int cs = 0; // Guarda os cent�simos de segundo.
	int i=0; //Vari�vel marcadora de posi��o.
	int b1 = 0, b1old = 0, b2 = 0, b2old = 0, b3 = 0, b3old = 0, toggle1 = 0, toggle2 = 0, toggle3 = 0, laps[4] = {0};// b1 == start/pause, b2 == reset, b3 == lap.
	unsigned int pta4, pta5, pta12, grow = 0;
	char c = 0;
	
	while(1){ //Daqui para frente o c�digo se repete at� o desligamento da placa.

		
		
		
//=====L� OS ESTADO DOS BOT�ES=============================================================================================================================
		
		pta4  = GPIOA_PDIR & (1<<4);
		pta5  = GPIOA_PDIR & (1<<5);
		pta12 = GPIOA_PDIR & (1<<12);
		
		if(!pta4){ b1=1;} else { b1=0;}//Aqui apenas lemos quais bot�es est�o pressionados no momento.
		if(!pta5){ b2=1;} else { b2=0;}
		if(!pta12){ b3=1;} else { b3=0;}
		
		//Os delay10uss s�o utilizados apenas para fins de debouncing.
		if(!b1 && b1old){toggle1 = 1;delay10us(50);}//Este tr�s if fazem apenas detec��o de borda de descida dos botoes.
		if(!b2 && b2old){toggle2 = 1; delay10us(50);}
		if(!b3 && b3old){toggle3 = 1; delay10us(50);}
		
		b1old = b1; b2old = b2; b3old = b3;
		
		if((UART0_S1 & UART0_S1_RDRF_MASK)){c = getchar_UART0();}
		
//=====LIDO ESTADO DOS BOT�ES======================================================================================================================


		
		
	
	
	
	
	
	
//======ESCREVENDO NO LCD=====================================================================================================================
		i=0;
		setPos(0, i);//Aponta o cursor na posi��o inicial.
		setString("Tempo ", 0, 0);
		
		i=5;
		setPos(0, i++);
		setChar(HR/10 + '0');//Exibe no LDC as horas transcorridas.
		setPos(0, i++);
		setChar(HR%10 + '0');//Exibe no LDC as horas transcorridas.
		
		setPos(0,i++);
		setChar(':');//Insere o separador.
		
		setPos(0, i++);
		setChar(MIN/10 + '0');//Exibe no LDC os minutos transcorridas.
		setPos(0, i++);
		setChar(MIN%10 + '0');//Exibe no LDC os minutos transcorridas.
		
		setPos(0, i++);
		setChar(':');//Insere o separador.
		
		setPos(0, i++);
		setChar(SEG/10 + '0');//Exibe no LDC os segundos transcorridas.
		setPos(0, i++);
		setChar(SEG%10 + '0');//Exibe no LDC os segundos transcorridas.
		
		setPos(0, i++);
		setChar('.');//Insere o separador.
		
		setPos(0, i++);
		setChar(CENT/10 + '0');//Exibe no LDC os cent�simos transcorridas.
		setPos(0, i++);
		setChar(CENT%10 + '0');//Exibe no LDC as cent�simos transcorridas.
//======ESCRITO NO LCD========================================================================================================================

		
		
		
		
		
//======ESCREVENDO NO TERMINAL=====================================================================================================================
		putchar_UART0('\r');//Retorna o caracter para o in�cio da linha para sobrescrev�-la.
		
		puts_UART0("Tempo ");
		
		putchar_UART0(HR/10 + '0');//Exibe no TERMINAL as horas transcorridas.
		putchar_UART0(HR%10 + '0');//Exibe no TERMINAL as horas transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(MIN/10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		putchar_UART0(MIN%10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(SEG/10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		putchar_UART0(SEG%10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		
		putchar_UART0('.');//Insere o separador
		
		putchar_UART0(CENT/10 + '0');//Exibe no TERMINAL os cent�simos transcorridas.
		putchar_UART0(CENT%10 + '0');//Exibe no TERMINAL as cent�simos transcorridas.
		
		
//======ESCRITO NO TERMINAL========================================================================================================================
		
		
		
		
		switch(c){
		
			case 's'://Se for pressionado s (start) dispare o cron�metro 
				grow = 1;
				c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
				break;
				
			case 'p'://Se for pressionado p (pause) pause o cron�metro 
				grow = 0;
				c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
				break;
				
			case 'r'://Se for pressionado r (reset) reset o cron�metro 
				toggle2 = 1;
				c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
				break;
				
			case'l'://Se for pressionado l (lap) salve a lap do cron�metro 
				toggle3  = 1;
				c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
				break;
				
			default:
				c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
				break;
		}
		
		delay10us(4);//Intervalo necess�rio para que o c�digo seja executada em 10ms.
		
		cs += grow;//Conta mais um cent�simo
		
		if(HR == 100) cs=0; //Se atingirmos o limite da contagem, reinicie o cron�metro.				
		
		if(toggle1){toggle1--; grow = 1 - grow;}//Se pressionar o bot�o 1, pause o programa, pois para de incrementar cs.
		
		if(toggle2){cs = 0;toggle2--;}//Se pressionar o bot�o 2, reinicie a contagem.
		
		if(toggle3){lap(cs, laps);toggle3--;}//Se pressionar o bot�o 3, conte um lap.

	}
	
	
	return 0;
}

void lap(int cs, int *n){
	
	int i;//Esta vari�vel serve para marcar posi��o tanto no LDC quanto no terminal.
	
	if(++n[0] >= 4) n[0] = 1;//Selcionar qual � a LAP sendo usada.
	n[n[0]] = cs;//Guarda o valor do cs na flag devida
	
	
//======ESCREVENDO NO LCD=====================================================================================================================
		i=0;
		setPos(1, i);//Aponta o cursor na posi��o inicial.
		setString("LAP", 1, 0);
		
		i=3;
		setPos(1, i++);
		setChar(n[0] + '0');
		setPos(1,i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(HR/10 + '0');//Exibe no LDC as horas transcorridas.
		setPos(1, i++);
		setChar(HR%10 + '0');//Exibe no LDC as horas transcorridas.
		
		setPos(1,i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(MIN/10 + '0');//Exibe no LDC os minutos transcorridas.
		setPos(1, i++);
		setChar(MIN%10 + '0');//Exibe no LDC os minutos transcorridas.
		
		setPos(1, i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(SEG/10 + '0');//Exibe no LDC os segundos transcorridas.
		setPos(1, i++);
		setChar(SEG%10 + '0');//Exibe no LDC os segundos transcorridas.
		
		setPos(1, i++);
		setChar('.');//Insere o separador.
		
		setPos(1, i++);
		setChar(CENT/10 + '0');//Exibe no LDC os cent�simos transcorridas.
		setPos(1, i++);
		setChar(CENT%10 + '0');//Exibe no LDC as cent�simos transcorridas.
//======ESCRITO NO LCD========================================================================================================================

		
		
		
		
		
//======ESCREVENDO NO TERMINAL=====================================================================================================================
	
		for(i=1; i<=n[0]; i++){	
		
		puts_UART0(" LAP");
		
		putchar_UART0(i + '0');
		
		putchar_UART0(' ');
		
		putchar_UART0(HRlap/10 + '0');//Exibe no TERMINAL as horas transcorridas.
		putchar_UART0(HRlap%10 + '0');//Exibe no TERMINAL as horas transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(MINlap/10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		putchar_UART0(MINlap%10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(SEGlap/10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		putchar_UART0(SEGlap%10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		
		putchar_UART0('.');//Insere o separador
		
		putchar_UART0(CENTlap/10 + '0');//Exibe no TERMINAL os cent�simos transcorridas.
		putchar_UART0(CENTlap%10 + '0');//Exibe no TERMINAL as cent�simos transcorridas.
		
	}
		
//======ESCRITO NO TERMINAL========================================================================================================================
		

}
