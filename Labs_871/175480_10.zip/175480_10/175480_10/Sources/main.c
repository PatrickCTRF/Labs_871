//175480_10

#include "UART.h"
#include "LCD.h"
#include"derivative.h"

#define HR (n[n[0]]/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MIN ((n[n[0]]%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEG (((n[n[0]]%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENT (((n[n[0]]%360000)%6000)%100) //Cent�simos.

#define HRlap (n[i]/360000) //Cada hora equivale a 360000 cent�simos de segundo.
#define MINlap ((n[i]%360000)/6000) //Cada minuto correponde a 6000 cent�simos (considerando apenas o RESTO da divis�o pelas horas).
#define SEGlap (((n[i]%360000)%6000)/100) //Cada segundo correponde a 100 cent�simos (considerando apenas o RESTO da divis�o pelos minutos).
#define CENTlap (((n[i]%360000)%6000)%100) //Cent�simos.

int cent_global = 0, toggle1 = 0, toggle2 = 0, toggle3 = 0, comando = 0, flag4 = 0, flag5 = 0, flag6 = 0;
char c=0;

void lap(int, int*, int);

void SysTick_Handler(){
	cent_global++;
}

void getCommand(void){
	
	if(c == 0 || (PORTA_ISFR == 0 && toggle1 == 0)){	
		comando = 0;										
	}
	if(c == '1' || (PORTA_ISFR == 0 && toggle1 == 1)){	
		comando = 1;										
	}
	if(c == '2' || (PORTA_ISFR == 32 && toggle1 == 0)){
		comando = 2;
		if(!(GPIOA_PDIR & (1<<12))){
			while(!(GPIOA_PDIR & (1<<12)));
			flag6 = 1;
			comando = 6;
		}
	}
	if(c == '3' || (PORTA_ISFR == 4096 && toggle1 == 0)){
		comando = 3;
		if(!(GPIOA_PDIR & (1<<5))){
			while(!(GPIOA_PDIR & (1<<5)));
			flag6 = 1;
			comando = 6;
		}
	}
	if(c == '4' || (toggle1 == 1 && !(GPIOA_PDIR & (1<<5)))){
		while(!(GPIOA_PDIR & (1<<5)));
		comando = comando*1;//Aguardo
		flag4 = 1;
		comando = 4;
		
	}
	if(c == '5' || (toggle1 == 1 && !(GPIOA_PDIR & (1<<12)))){
		while(!(GPIOA_PDIR & (1<<12)));
		comando = comando*1;//Aguardo
		flag5 = 1;
		comando = 5;
		
	}
	if(c == '6'){
		flag6 = 1;
		comando = 6;
	}
}

void NMI_Handler(){
	toggle1 = 1;
	getCommand();
	toggle1 = 0;
	return;
}

void PORTA_IRQHandler(){
	
	getCommand();
	
	PORTA_ISFR = (1<<5);
	PORTA_ISFR = (1<<12);
	
	
	//if(comando==2)
}

void UART0_IRQHandler(){
	c = getchar_UART0();
	getCommand();
	c=0;
}

int main(void){
	
	
	
//======TODA A PARTE DE INICIALIZA��O=====================================================================================================================
	
	inicGPIO();//Fazendo toda a inicializa��o de software necess�ria.
	inicLCD(2);
	init_UART0();
	
	PORTA_PCR4 = 0x100;
	PORTA_PCR5 = 0x100;
	PORTA_PCR12 = 0x100;
	
	GPIOA_PDDR &= 0xFFFFEFCF;//Zera os bits 12, 5 e 4.
		
	
	PORTA_PCR5 = (0x100);
	PORTA_PCR5 |= (1<<19);
	PORTA_PCR5 |= (1<<16);
	PORTA_PCR12 = (0x100);
	PORTA_PCR12 |= (1<<19);
	PORTA_PCR12 |= (1<<16);
	PORTA_PCR4 = 0x0700;
	NVIC_ISER = (1<<30); //Habilita interrup��o na Porta A e na UART0.
	NVIC_ISER |= (1<<12);
	UART0_C2 |= (1<<5);//Habilita interrup��o de RECEP��O de caracteres na UART0.
		
	
	puts_UART0("\r\n");// Ajusta o terminal para uma linha limpa.
	
	clear();//Limpa o lcd.
	
	SYST_RVR=210429;//Quantidade adequada para a interrup��o ocorrer a cada 10ms (verificado no oscilosc�pio).
	SYST_CVR=0;//Passa qualquer valor para CVR, o que faz isso voltar a zero e recarregar o valor a partir de RVR.
	SYST_CSR= 0b110;//Seta o registrador de controle para receber clock da CPU, lan�ar a exce��o do systic e n�o come�ar a contagem (respectivamente aos bits desta palavra).

//======FIM DA PARTE DE INICIALIZA��O=====================================================================================================================
	
	
	
	
	//int cent_global = 0; // Guarda os cent�simos de segundo.
	int i=0; //Vari�vel marcadora de posi��o.
	int b1 = 0, b1old = 0, b2 = 0, b2old = 0, b3 = 0, b3old = 0, laps[4] = {0};// b1 == start/pause, b2 == reset, b3 == lap.
	unsigned int pta4, pta5, pta12;
	char c = 0;
	int hr=0, min=0, seg=0, cent=0;
	
	while(1){ //Daqui para frente o c�digo se repete at� o desligamento da placa.

	
		
		
//=====L� OS ESTADO DOS BOT�ES=============================================================================================================================
		/*
		pta4  = GPIOA_PDIR & (1<<4);
		pta5  = GPIOA_PDIR & (1<<5);
		pta12 = GPIOA_PDIR & (1<<12);
		
		if(!pta4){ b1=1;} else { b1=0;}//Aqui apenas lemos quais bot�es est�o pressionados no momento.
		if(!pta5){ b2=1;} else { b2=0;}
		if(!pta12){ b3=1;} else { b3=0;}
		
		//Os delay10us s�o utilizados apenas para fins de debouncing.
		if(!b1 && b1old){toggle1 = 1;delay10us(50);}//Este tr�s if fazem apenas detec��o de borda de descida dos botoes.
		if(!b2 && b2old){toggle2 = 1; delay10us(50);}
		if(!b3 && b3old){toggle3 = 1; delay10us(50);}
		
		b1old = b1; b2old = b2; b3old = b3;
		
		if((UART0_S1 & UART0_S1_RDRF_MASK)){c = getchar_UART0();}
		*/
//=====LIDO ESTADO DOS BOT�ES======================================================================================================================

		
		
		
		cent = (((cent_global%360000)%6000)%100);//Obtendo os valores de interesse.
		if(cent==0 && cent_global){seg++; cent=0;}
		if(seg==60){min++; seg=0;}
		if(min==60){hr++; min=0;}
	
	
		
	
//======ESCREVENDO NO LCD=====================================================================================================================
		i=0;
		setPos(0, i);//Aponta o cursor na posi��o inicial.
		setString("Tempo ", 0, 0);
		
		i=5;
		setPos(0, i++);
		setChar(hr/10 + '0');//Exibe no LDC as horas transcorridas.
		setPos(0, i++);
		setChar(hr%10 + '0');//Exibe no LDC as horas transcorridas.
		
		setPos(0,i++);
		setChar(':');//Insere o separador.
		
		setPos(0, i++);
		setChar(min/10 + '0');//Exibe no LDC os minutos transcorridas.
		setPos(0, i++);
		setChar(min%10 + '0');//Exibe no LDC os minutos transcorridas.
		
		setPos(0, i++);
		setChar(':');//Insere o separador.
		
		setPos(0, i++);
		setChar(seg/10 + '0');//Exibe no LDC os segundos transcorridas.
		setPos(0, i++);
		setChar(seg%10 + '0');//Exibe no LDC os segundos transcorridas.
		
		setPos(0, i++);
		setChar('.');//Insere o separador.
		
		setPos(0, i++);
		setChar(cent/10 + '0');//Exibe no LDC os cent�simos transcorridas.
		setPos(0, i++);
		setChar(cent%10 + '0');//Exibe no LDC as cent�simos transcorridas.
//======ESCRITO NO LCD========================================================================================================================

		
		
		
		
		
//======ESCREVENDO NO TERminAL=====================================================================================================================
		putchar_UART0('\r');//Retorna o caracter para o in�cio da linha para sobrescrev�-la.
		
		puts_UART0("Tempo ");
		
		putchar_UART0(hr/10 + '0');//Exibe no TERminAL as horas transcorridas.
		putchar_UART0(hr%10 + '0');//Exibe no TERminAL as horas transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(min/10 + '0');//Exibe no TERminAL os minutos transcorridas.
		putchar_UART0(min%10 + '0');//Exibe no TERminAL os minutos transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(seg/10 + '0');//Exibe no TERminAL os segundos transcorridas.
		putchar_UART0(seg%10 + '0');//Exibe no TERminAL os segundos transcorridas.
		
		putchar_UART0('.');//Insere o separador
		
		putchar_UART0(cent/10 + '0');//Exibe no TERminAL os cent�simos transcorridas.
		putchar_UART0(cent%10 + '0');//Exibe no TERminAL as cent�simos transcorridas.
		
		
//======ESCRITO NO TERMINAL========================================================================================================================
		
		
		
		/*if(c != 0){	
			switch(c){
			
				case 's'://Se for pressionado s (start) dispare o cron�metro 
					SYST_CSR = 0b111;
					c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
					break;
					
				case 'p'://Se for pressionado p (pause) pause o cron�metro 
					SYST_CSR = 0b110;
					c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
					break;
					
				case 'r'://Se for pressionado r (reset) reset o cron�metro 
					toggle2 = 1;
					c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
					break;
					
				case'l'://Se for pressionado l (lap) salve a lap do cron�metro 
					toggle3  = 1;
					c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
					break;
					
				default:
					c = 0;//Zera o caractere para n�o entrar novamente logo em seguida neste switch case.
					break;
			}
		}*/
		
		if(flag4){comando = 4; flag4 = 0;}
		if(flag5){comando = 5; flag5 = 0;}
		if(flag6){comando = 6; flag6 = 0;}
		
		if(hr == 100) cent_global=0; //Se atingirmos o limite da contagem, reinicie o cron�metro.				
		
		if(comando==1){comando = 0; SYST_CSR = 0b111;}//Se pressionar o bot�o 1, pause o programa, pois para de atualizar o contador registrador de CVR (ativando ou desativando o primeiro pino do registrador de controle).
		
		if(comando==2){comando = 0; SYST_CSR = 0b110;}
		
		if(comando==3){hr=min=seg=cent=cent_global= 0;comando = 0;}//Se pressionar o bot�o 2, reinicie a contagem.
		
		if(comando==4){lap(cent_global, laps, 1);comando = 0;}//Se pressionar o bot�o 3, conte um lap.
		
		if(comando==5){lap(cent_global, laps, 2);comando = 0;}//Se pressionar o bot�o 3, conte um lap.
		
		if(comando==6){lap(cent_global, laps, 3);comando = 0;}//Se pressionar o bot�o 3, conte um lap.
		

	}
	
	
	return 0;
}

void lap(int cent_global, int *n, int numero){
	
	int i;//Esta vari�vel serve para marcar posi��o tanto no LDC quanto no terminal.
	
	n[0] = numero;//Selcionar qual � a LAP sendo usada.
	n[n[0]] = cent_global;//Guarda o valor do cent_global na flag devida
	
	
//======ESCREVENDO NO LCD=====================================================================================================================
		i=0;
		setPos(1, i);//Aponta o cursor na posi��o inicial.
		setString("LAP", 1, 0);
		
		i=3;
		setPos(1, i++);
		setChar(n[0] + '0');//Mostra qual a lap sendo exibida no lcd.
		setPos(1,i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(HR/10 + '0');//Exibe no LDC as horas transcorridas.
		setPos(1, i++);
		setChar(HR%10 + '0');//Exibe no LDC as horas transcorridas.
		
		setPos(1,i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(MIN/10 + '0');//Exibe no LDC os minutos transcorridas.
		setPos(1, i++);
		setChar(MIN%10 + '0');//Exibe no LDC os minutos transcorridas.
		
		setPos(1, i++);
		setChar(':');//Insere o separador.
		
		setPos(1, i++);
		setChar(SEG/10 + '0');//Exibe no LDC os segundos transcorridas.
		setPos(1, i++);
		setChar(SEG%10 + '0');//Exibe no LDC os segundos transcorridas.
		
		setPos(1, i++);
		setChar('.');//Insere o separador.
		
		setPos(1, i++);
		setChar(CENT/10 + '0');//Exibe no LDC os cent�simos transcorridas.
		setPos(1, i++);
		setChar(CENT%10 + '0');//Exibe no LDC as cent�simos transcorridas.
//======ESCRITO NO LCD========================================================================================================================

		
		
		
		
		
//======ESCREVENDO NO TERMINAL=====================================================================================================================
	
		for(i=1; i<=n[0]; i++){
		
		puts_UART0(" LAP");
		
		putchar_UART0(i + '0');
		
		putchar_UART0(' ');
		
		putchar_UART0(HRlap/10 + '0');//Exibe no TERMINAL as horas transcorridas.
		putchar_UART0(HRlap%10 + '0');//Exibe no TERMINAL as horas transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(MINlap/10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		putchar_UART0(MINlap%10 + '0');//Exibe no TERMINAL os minutos transcorridas.
		
		putchar_UART0(':');//Insere o separador
		
		putchar_UART0(SEGlap/10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		putchar_UART0(SEGlap%10 + '0');//Exibe no TERMINAL os segundos transcorridas.
		
		putchar_UART0('.');//Insere o separador
		
		putchar_UART0(CENTlap/10 + '0');//Exibe no TERMINAL os cent�simos transcorridas.
		putchar_UART0(CENTlap%10 + '0');//Exibe no TERMINAL as cent�simos transcorridas.
		
	}
		
//======ESCRITO NO TERMINAL========================================================================================================================
		

}
