#define MWSR                   0x00  /* Master write  */
#define MRSW                   0x01  /* Master read */
#define i2c_DisableAck()       I2C0_C1 |= I2C_C1_TXAK_MASK // Byte de acknowledge signal ("sinal de reconhecimento da sequencia serial") � enviado no pr�ximo ou atual byte sendo recebido.
#define i2c_EnableAck()        I2C0_C1 &= ~I2C_C1_TXAK_MASK // Byte de acknowledge signal ("sinal de reconhecimento da sequencia serial") n�o � enviado no pr�ximo nem atual byte sendo recebido.
#define i2c_RepeatedStart()    I2C0_C1 |= I2C_C1_RSTA_MASK // O sinal de repeat start (RSTA) � utilizado quando o MASTER deseja se comunicar novamente com um SLAVE sem desocupar o bus enviando um sinal de STOP.
#define i2c_EnterRxMode()      I2C0_C1 &= ~I2C_C1_TX_MASK // 
#define i2c_write_byte(data)   I2C0_D = data //

//Esta fun��o habilita os bits de I2C0_C1 para modo de TRANSMISS�O e MASTER MODE.
#define i2c_Start()            I2C0_C1 |= I2C_C1_TX_MASK;\
                               I2C0_C1 |= I2C_C1_MST_MASK

//Esta fun��o habilita os bits de I2C0_C1 para modo de RECEP��O e SLAVE MODE.
#define i2c_Stop()             I2C0_C1 &= ~I2C_C1_MST_MASK;\
                               I2C0_C1 &= ~I2C_C1_TX_MASK

//Esta fun��o aguarda at� que haja uma interrup��o devido ao I2C. Quando amesma ocorrer, limpa-se a flag I2C_S->IICIF.
#define i2c_Wait()               while((I2C0_S & I2C_S_IICIF_MASK)==0) {} \
                                  I2C0_S |= I2C_S_IICIF_MASK;

void initI2C(void);
void IIC_StartTransmission (char SlaveID, char Mode);
void I2CWriteRegister(char SlaveID, char u8RegisterAddress, char u8Data);
char I2CReadRegister(char SlaveID, char u8RegisterAddress);
void I2CReadMultiRegisters(char SlaveID, char u8RegisterAddress, char n, char * r);
