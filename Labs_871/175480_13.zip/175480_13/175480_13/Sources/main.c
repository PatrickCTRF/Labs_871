//175480_13


/*
 * Este programa l� a modula��o por largura de pulso no pino PTB0.
 * 
 * Resultados exibidos no display e no terminal.
 * 
 */

#include "UART.h"
#include "LCD.h"
#include"derivative.h"



volatile unsigned int borda_detectada = 0, n_overflows = 0, tempo_largura = 0, tempo_periodo = 0, old_tempo_largura = 0, old_tempo_periodo = 0, contagem_no_inicio = 0;



void FTM1_IRQHandler(){//Tratando as interrup��es provenientes do TPM1.
	
	old_tempo_largura = tempo_largura;//Caso haja o bug e o sistema leia um valor muito alto, reutiliza os valores anteriores.
	old_tempo_periodo = tempo_periodo;
	
	//borda_detectada � igual a 1 na primeira borda de subida detectada.
	//� resetada para 0 quando o segundo pulso desce, reiniciando-se o ciclo de medi��o quando temos o novo pulso de subida.
	
	
	if(TPM1_STATUS & TPM_STATUS_TOF_MASK){//Caso seja interrup��o de overflow...
		//Caso borda de subida seja diferente de zero (e somente se for diferente de zero), estaremos realizando a medi��o e � essencial marcar quantas vezes o contador resetou.
		
		n_overflows++;
	}
	
	if(TPM1_STATUS & TPM_STATUS_CH0F_MASK){//Caso seja interrup��o de canal...
			
		if(borda_detectada){//Se borda_detectada for positiva, precisamos decrement�-la para saber em que etapa estamos.

			tempo_largura = TPM1_C0V  - contagem_no_inicio + n_overflows*TPM1_MOD;//Se ultrapassou a contagem...
			
			TPM1_C0SC &= 0xF0;
			TPM1_C0SC |= 0b100;

		}else{

			tempo_periodo = TPM1_C0V  - contagem_no_inicio + n_overflows*TPM1_MOD;
			
			n_overflows = 0;//Recome�ando a medi��o.
			contagem_no_inicio = TPM1_C0V;
			TPM1_C0SC &= 0xF0;
			TPM1_C0SC |= 0b1000;
			
		}
		

		borda_detectada = 1 - borda_detectada;//inverte o valor BOOLEANO de borda detectada para sabermos se estamos esperando por uma borda de subida ou descida.
		
	}

	if(tempo_largura>209979||tempo_periodo>209979){//Estes valores seriam equivalentes a ondas de mais de 1segundo, que n�o s�o aceitas pelo dispositivo adequadamente.
		
		tempo_largura = old_tempo_largura;//Caso haja o bug e o sistema leia um valor muito alto, reutiliza os valores anteriores.
		tempo_periodo = old_tempo_periodo;
	}

	TPM1_STATUS = 0xFFFFFFFF;//Reseta todas as flags para nao chamar nenhuma interrup��o em momento indevido e recorrentemente.
	//Possivelmente n�o h� necessidade de se apagar este registrador tamb�m, mas estou fazendo-o por garantia.
}


int main(void){
	
	
//======TODA A PARTE DE INICIALIZA��O=====================================================================================================================
	
	inicGPIO();//Fazendo toda a inicializa��o de software necess�ria.
	inicLCD(2);
	
	GPIOB_PDDR &= 0xFFFFFFFE;//Seta pino 0 como entrada.
	SIM_SOPT2 |= (1<<24);//Enviando clock at� os TPMs.
	SIM_SCGC5 |= (1<<10);//Ativando clock da PORTB.
	SIM_SCGC6 = (1<<25);//Ativa o clock de TPM1.
	TPM1_SC = 0b1000000;//TOIE ativado, Prescale em 1 (Quanto mais r�pido o clock, menor ser� a incerteza em cada unidade contada), LPTPM clock DISABLED (pois o center aligned s� se altera com contador desativado, � um pino protegido contra escrita em momento indevido), Edge-aligned PWM (CPWMS em 0).
	TPM1_SC |= 0b001000;//Depois de configurar os pinos necess�rios, podemos ativar o contador (LPTPM counter).LPTPM clock ativado.
	TPM1_MOD = 0xFFFF;//Representa at� quanto o contador vai contar subindo e depois contar at� zero novamente. Logo, este valor representa o per�odo do pulso de chaveamento do PWM.
	TPM1_C0SC = 0;//O manual indica que este canal deve estar desativado para ser configurado, ent�o vou zer�-lo antes de come�ar qualquer configura��o.
	TPM1_C0SC = 0b1000100;//Canal configurado para capturar bordas de descida e subida do pulso lido (gerando interrupa��o CHIE flag CHF).
	PORTB_PCR0 = (0b11<<8);//Seta o MUX para transmitir neste pino a alternative 3 (ALT3), que envia o TPM1_CH0 para c�.
	TPM1_CNT = 0;
	NVIC_ISER |= (1<<18);//Habilita as interrup��es provenientes do m�dulo TPM1 (inclusive seus canais).
	
	
	clear();//Limpa o lcd.
	
	
//======FIM DA PARTE DE INICIALIZA��O=====================================================================================================================
	
	
	char string_auxiliar_de_impressao [100] = {0};
	unsigned int n_media = 0, largura_media = 0, periodo_medio = 0;
	

	
	while(1){ //Daqui para frente o c�digo se repete at� o desligamento da placa.
		
		
		
		if(n_media>=100){//M�dias para se aproximar do valor real.
			setString("     ", 0, 11);//Limpa o lcd.
			setString("     ", 1, 11);//Limpa o lcd.
			
			largura_media /= (n_media*21);//21 � o coeficiente pra ajustar o periodo de clock e o periodo de um microsegundo real
			periodo_medio /= (n_media*21);
				
			setString("Largura(us)", 0, 0);
			int2ascii10(largura_media, string_auxiliar_de_impressao);
			setString(string_auxiliar_de_impressao, 0, 11);
			setString("Periodo(us)", 1, 0);
			int2ascii10(periodo_medio,string_auxiliar_de_impressao);
			setString(string_auxiliar_de_impressao, 1, 11);
			
			n_media = 0;
			periodo_medio = 0;
			largura_media = 0;
			
			delay10us(10000);//Tempo para o usu�rio visualizar.
			
		}else{
			
			periodo_medio += tempo_periodo;
			largura_media += tempo_largura;
			n_media++;
			
		}
		
	}
	
	return 0;
}
