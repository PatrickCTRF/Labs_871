/*
 * LCD.h
 *
 *  Created on: Sep 28, 2016
 *      Author: ea871
 */

#ifndef LCD_H_
#define LCD_H_

void inicGPIO();

void delay10us(int n);

void inicLCD(int qtsLinhas);

void passaComando(unsigned int comando);

void clear();

void setString(char frase[], int linha, int coluna);

void setChar(char caractere);

void setPos(int linha, int coluna);

void shift_left();

void shift_right();

#endif /* LCD_H_ */
